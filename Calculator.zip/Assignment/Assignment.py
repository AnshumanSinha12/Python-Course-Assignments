from tkinter import *

# STEP 1: Create main window

window = Tk()
window.title("Calculator")
window.geometry("400x500")


# STEP 2: Entry widget (for display)

e = Entry(window, width=25, borderwidth=5, relief="ridge", font=("Arial", 20))
e.grid(row=0, column=0, columnspan=4, padx=10, pady=10)


# STEP 3: Functions

def click(num):
    """Append a digit or dot to the entry box"""
    current = e.get()
    e.delete(0, END)
    e.insert(0, current + str(num))


def set_op(op):
    """Save the first number and the chosen operator"""
    global first_num, operation
    try:
        first_num = float(e.get())
    except ValueError:
        first_num = 0
    operation = op
    e.delete(0, END)


def equal():
    """Perform the calculation and show the result"""
    try:
        second_num = float(e.get())
    except ValueError:
        e.delete(0, END)
        e.insert(0, "Error")
        return

    e.delete(0, END)
    try:
        if operation == "add":
            e.insert(0, first_num + second_num)
        elif operation == "sub":
            e.insert(0, first_num - second_num)
        elif operation == "mul":
            e.insert(0, first_num * second_num)
        elif operation == "div":
            e.insert(0, first_num / second_num)
    except ZeroDivisionError:
        e.insert(0, "Error")


def clear():
    """Clear the entry box"""
    e.delete(0, END)


# STEP 4: Buttons
# Digits
digits = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2),
    ('0', 4, 0), ('.', 4, 1)
]

for (text, row, col) in digits:
    Button(window, text=text, width=10, height=2,command=lambda t=text: click(t)).grid(row=row, column=col, padx=5, pady=5)

# Operators
Button(window, text="+", width=10, height=2, command=lambda: set_op("add")).grid(row=1, column=3)
Button(window, text="-", width=10, height=2, command=lambda: set_op("sub")).grid(row=2, column=3)
Button(window, text="*", width=10, height=2, command=lambda: set_op("mul")).grid(row=3, column=3)
Button(window, text="/", width=10, height=2, command=lambda: set_op("div")).grid(row=4, column=3)

# Equal and Clear
Button(window, text="=", width=10, height=2, command=equal).grid(row=4, column=2)
Button(window, text="Clear", width=23, height=2, command=clear).grid(row=5, column=0, columnspan=2, pady=10)


# STEP 5: Mainloop
window.mainloop()
